import{r as f}from"./index.562753b1.js";const i={English:"en"};Object.values(i);const v={indexName:"XXXXXXXXXX",appId:"XXXXXXXXXX",apiKey:"XXXXXXXXXX"};var a={exports:{}},X={};/**
 * @license React
 * react-jsx-runtime.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var l=f.exports,u=Symbol.for("react.element"),c=Symbol.for("react.fragment"),m=Object.prototype.hasOwnProperty,y=l.__SECRET_INTERNALS_DO_NOT_USE_OR_YOU_WILL_BE_FIRED.ReactCurrentOwner,O={key:!0,ref:!0,__self:!0,__source:!0};function _(t,e,s){var r,o={},n=null,p=null;s!==void 0&&(n=""+s),e.key!==void 0&&(n=""+e.key),e.ref!==void 0&&(p=e.ref);for(r in e)m.call(e,r)&&!O.hasOwnProperty(r)&&(o[r]=e[r]);if(t&&t.defaultProps)for(r in e=t.defaultProps,e)o[r]===void 0&&(o[r]=e[r]);return{$$typeof:u,type:t,key:n,ref:p,props:o,_owner:y.current}}X.Fragment=c;X.jsx=_;X.jsxs=_;(function(t){t.exports=X})(a);export{v as A,i as K,a as j};
